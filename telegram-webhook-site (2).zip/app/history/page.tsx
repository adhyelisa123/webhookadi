import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, XCircle, MessageSquare } from "lucide-react"

interface HistoryEntry {
  timestamp: string
  message: string
  telegram: {
    success: boolean
    chatId: string | null
    error: string | null
  }
  twitter: {
    success: boolean
    accountUsed: number | null
    error: string | null
  }
}

async function getHistory(): Promise<HistoryEntry[]> {
  const res = await fetch("/api/history", {
    cache: "no-store", // Pastikan data selalu segar
  })

  if (!res.ok) {
    let errorMessage = `Failed to load history: HTTP ${res.status}`
    try {
      const errorData = await res.json()
      if (errorData && errorData.error) {
        errorMessage = `Failed to load history: ${errorData.error}`
      } else {
        errorMessage = `Failed to load history: HTTP ${res.status} - ${await res.text()}`
      }
    } catch (parseError) {
      // Jika respons bukan JSON atau gagal di-parse
      errorMessage = `Failed to load history: HTTP ${res.status} (Could not parse error response from server)`
    }
    console.error(errorMessage)
    throw new Error(errorMessage)
  }

  const data = await res.json()
  return data.history || []
}

export default async function HistoryPage() {
  let history: HistoryEntry[] = []
  let errorFetchingHistory: string | null = null

  try {
    history = await getHistory()
  } catch (error: any) {
    errorFetchingHistory = error.message
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="text-center py-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Webhook History</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            All alerts processed by the webhook, including delivery status to Telegram and Twitter.
          </p>
        </div>

        {errorFetchingHistory ? (
          <Card>
            <CardContent className="p-6 text-center text-red-600">
              <p className="font-semibold mb-2">Error loading history:</p>
              <p>{errorFetchingHistory}</p>
              <p className="mt-2 text-sm text-gray-500">
                Please ensure Upstash Redis integration is active and `UPSTASH_REDIS_REST_URL` and
                `UPSTASH_REDIS_REST_TOKEN` are correctly configured in Vercel and redeploy.
              </p>
            </CardContent>
          </Card>
        ) : history.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center text-gray-500">
              No history entries yet. Send some alerts to the webhook!
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {history.map((entry, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <MessageSquare className="h-5 w-5 text-blue-600" />
                    Alert Received
                    <span className="ml-auto text-sm font-normal text-gray-500">
                      {new Date(entry.timestamp).toLocaleString()}
                    </span>
                  </CardTitle>
                  <CardDescription className="text-base font-medium text-gray-800 whitespace-pre-wrap">
                    {entry.message}
                  </CardDescription>
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Telegram Status */}
                  <div className="flex flex-col gap-2">
                    <h3 className="font-semibold text-blue-700 flex items-center gap-2">
                      {entry.telegram.success ? (
                        <CheckCircle className="h-4 w-4 text-green-500" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-500" />
                      )}
                      Telegram Delivery
                    </h3>
                    <div className="text-sm text-gray-700">
                      Status:{" "}
                      <Badge variant={entry.telegram.success ? "default" : "destructive"}>
                        {entry.telegram.success ? "Success" : "Failed"}
                      </Badge>
                    </div>
                    {entry.telegram.chatId && (
                      <div className="text-sm text-gray-700">
                        Chat ID: <span className="font-mono">{entry.telegram.chatId}</span>
                      </div>
                    )}
                    {entry.telegram.error && <div className="text-sm text-red-600">Error: {entry.telegram.error}</div>}
                  </div>

                  {/* Twitter Status */}
                  <div className="flex flex-col gap-2">
                    <h3 className="font-semibold text-sky-700 flex items-center gap-2">
                      {entry.twitter.success ? (
                        <CheckCircle className="h-4 w-4 text-green-500" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-500" />
                      )}
                      Twitter Post
                    </h3>
                    <div className="text-sm text-gray-700">
                      Status:{" "}
                      <Badge variant={entry.twitter.success ? "default" : "destructive"}>
                        {entry.twitter.success ? "Success" : "Failed"}
                      </Badge>
                    </div>
                    {entry.twitter.accountUsed && (
                      <div className="text-sm text-gray-700">
                        Account: <span className="font-mono">#{entry.twitter.accountUsed}</span>
                      </div>
                    )}
                    {entry.twitter.error && <div className="text-sm text-red-600">Error: {entry.twitter.error}</div>}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
