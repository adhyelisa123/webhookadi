import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { Toaster } from "@/components/ui/toaster"
import Link from "next/link" // Import Link component
import { Home, History } from "lucide-react" // Import icons

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Telegram Webhook - Forward Alerts to Telegram",
  description: "A webhook service that forwards alerts and messages from any service directly to your Telegram group.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <div className="flex flex-col min-h-screen">
          <nav className="bg-gray-800 text-white p-4 shadow-md">
            <div className="max-w-4xl mx-auto flex justify-between items-center">
              <h1 className="text-xl font-bold">Webhook Dashboard</h1>
              <div className="flex space-x-4">
                <Link href="/" className="flex items-center gap-2 hover:text-blue-300 transition-colors">
                  <Home className="h-5 w-5" />
                  Webhook
                </Link>
                <Link href="/history" className="flex items-center gap-2 hover:text-blue-300 transition-colors">
                  <History className="h-5 w-5" />
                  History
                </Link>
              </div>
            </div>
          </nav>
          <main className="flex-grow">{children}</main>
        </div>
        <Toaster />
      </body>
    </html>
  )
}
