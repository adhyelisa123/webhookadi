"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Copy, CheckCircle, Webhook } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function WebhookPage() {
  const [webhookUrl, setWebhookUrl] = useState("")
  const [testMessage, setTestMessage] = useState("Test alert from webhook")
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    // Get the current URL for the webhook endpoint
    if (typeof window !== "undefined") {
      setWebhookUrl(`${window.location.origin}/api/webhook`)
    }
  }, [])

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      toast({
        title: "Copied!",
        description: "Webhook URL copied to clipboard",
      })
    } catch (err) {
      toast({
        title: "Failed to copy",
        description: "Please copy the URL manually",
        variant: "destructive",
      })
    }
  }

  const testWebhook = async () => {
    setIsLoading(true)
    try {
      const response = await fetch("/api/webhook", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ message: testMessage }),
      })

      if (response.ok) {
        toast({
          title: "Success!",
          description: "Test message sent to Telegram",
        })
      } else {
        const errorText = await response.text()
        toast({
          title: "Error",
          description: errorText,
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send test message",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center py-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Webhook className="h-8 w-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-900">Telegram Webhook</h1>
          </div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Forward alerts and messages from any service directly to your Telegram group. Supports both JSON and plain
            text formats.
          </p>
        </div>

        {/* Webhook URL Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Webhook className="h-5 w-5" />
              Webhook Endpoint
            </CardTitle>
            <CardDescription>
              Use this URL as your webhook endpoint in TradingView, monitoring services, or any application
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-sm font-medium mb-2 block">Primary Webhook URL</Label>
              <div className="flex gap-2">
                <Input value={webhookUrl} readOnly className="font-mono text-sm" />
                <Button onClick={() => copyToClipboard(webhookUrl)} variant="outline" size="icon">
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="flex gap-2">
              <Badge variant="secondary">POST</Badge>
              <Badge variant="outline">JSON</Badge>
              <Badge variant="outline">Plain Text</Badge>
            </div>
          </CardContent>
        </Card>

        {/* Test Webhook Card */}
        <Card>
          <CardHeader>
            <CardTitle>Test Webhook</CardTitle>
            <CardDescription>Send a test message to verify your webhook is working correctly</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="testMessage">Test Message</Label>
              <Input
                id="testMessage"
                value={testMessage}
                onChange={(e) => setTestMessage(e.target.value)}
                placeholder="Enter your test message"
              />
            </div>
            <Button onClick={testWebhook} disabled={isLoading || !testMessage.trim()} className="w-full">
              {isLoading ? "Sending..." : "Send Test Message"}
            </Button>
          </CardContent>
        </Card>

        {/* Usage Examples Card */}
        <Card>
          <CardHeader>
            <CardTitle>Usage Examples</CardTitle>
            <CardDescription>How to send messages to your webhook from different sources</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* JSON Format */}
            <div>
              <h4 className="font-semibold mb-2">JSON Format (TradingView, APIs)</h4>
              <div className="bg-gray-900 text-gray-100 p-4 rounded-lg font-mono text-sm overflow-x-auto">
                <div className="text-green-400">POST {webhookUrl}</div>
                <div className="text-blue-400">Content-Type: application/json</div>
                <br />
                <div className="text-yellow-300">{"{"}</div>
                <div className="ml-4 text-white">"message": "🚨 ALERT: BTC price crossed $50,000!"</div>
                <div className="text-yellow-300">{"}"}</div>
              </div>
            </div>

            {/* Plain Text Format */}
            <div>
              <h4 className="font-semibold mb-2">Plain Text Format</h4>
              <div className="bg-gray-900 text-gray-100 p-4 rounded-lg font-mono text-sm overflow-x-auto">
                <div className="text-green-400">POST {webhookUrl}</div>
                <div className="text-blue-400">Content-Type: text/plain</div>
                <br />
                <div className="text-white">🚨 ALERT: Server CPU usage is above 90%</div>
              </div>
            </div>

            {/* cURL Example */}
            <div>
              <h4 className="font-semibold mb-2">cURL Example</h4>
              <div className="bg-gray-900 text-gray-100 p-4 rounded-lg font-mono text-sm overflow-x-auto">
                <div className="text-green-400">curl -X POST {webhookUrl} \</div>
                <div className="text-blue-400 ml-4">-H "Content-Type: application/json" \</div>
                <div className="text-white ml-4">{`-d '{"message": "Test alert from cURL"}'`}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Features Card */}
        <Card>
          <CardHeader>
            <CardTitle>Features</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                <div>
                  <h4 className="font-semibold">Multiple Content Types</h4>
                  <p className="text-sm text-gray-600">Supports JSON and plain text messages</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                <div>
                  <h4 className="font-semibold">Markdown Escaping</h4>
                  <p className="text-sm text-gray-600">Automatically escapes special characters for Telegram</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                <div>
                  <h4 className="font-semibold">Error Handling</h4>
                  <p className="text-sm text-gray-600">Comprehensive error handling and logging</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                <div>
                  <h4 className="font-semibold">Line Break Support</h4>
                  <p className="text-sm text-gray-600">Converts \n to actual line breaks</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                <div>
                  <h4 className="font-semibold">Dual Platform Posting</h4>
                  <p className="text-sm text-gray-600">Automatically posts to both Telegram and Twitter</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                <div>
                  <h4 className="font-semibold">Twitter Auto-Failover</h4>
                  <p className="text-sm text-gray-600">Switches between 2 Twitter accounts when rate limited</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
