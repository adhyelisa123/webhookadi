import { NextResponse } from "next/server"
import { Redis } from "@upstash/redis" // Import Redis from Upstash

// Initialize Upstash Redis client using fromEnv()
const redis = Redis.fromEnv()

const HISTORY_REDIS_KEY = "webhook_history_v2" // Kunci riwayat yang baru

export async function GET() {
  try {
    // fromEnv() akan secara otomatis memeriksa variabel lingkungan,
    // jadi kita tidak perlu validasi eksplisit di sini,
    // tetapi error akan muncul di log jika variabel tidak ada.

    let history: any[] = []
    try {
      const redisHistory = await redis.get<any[]>(HISTORY_REDIS_KEY)
      if (redisHistory) {
        history = redisHistory
        console.log("✅ History retrieved from Upstash Redis.")
      } else {
        console.log("ℹ️ History key does not exist in Upstash Redis. Returning empty history.")
      }
    } catch (redisError: any) {
      // Tangkap error dengan tipe any
      console.error("❌ Error retrieving history from Upstash Redis:", redisError)
      // Berikan pesan error yang lebih informatif jika terjadi masalah dengan Redis
      return NextResponse.json(
        {
          error: `Failed to fetch history from Upstash Redis. Please check your Upstash Redis environment variables (UPSTASH_REDIS_REST_URL, UPSTASH_REDIS_REST_TOKEN) and ensure your database is accessible. Error details: ${redisError.message}`,
        },
        { status: 500 },
      )
    }

    return NextResponse.json({ history })
  } catch (error) {
    console.error("❌ Unexpected error in history API:", error)
    return NextResponse.json({ error: "Failed to fetch history. Check server logs for details." }, { status: 500 })
  }
}
