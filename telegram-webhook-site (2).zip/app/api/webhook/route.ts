import { type NextRequest, NextResponse } from "next/server"
import { createHmac, randomBytes } from "crypto"
import { Redis } from "@upstash/redis" // Import Redis from Upstash

// Initialize Upstash Redis client using fromEnv()
const redis = Redis.fromEnv()

// === HARDCODED TELEGRAM CONFIG ===
const TELEGRAM_BOT_TOKEN = "8294889123:AAGH3XDxxIvz5sYkHdS6I5rhYldSPZswE98"

// Map chat IDs to keywords
const TELEGRAM_CHAT_MAP = [
  { keywords: ["SNR", "snr"], chatId: "-1002670253489" },
  { keywords: ["SMA", "sma"], chatId: "-1002806867434" },
  // Add more mappings here if needed
]

// Default chat ID if no keywords are found
const TELEGRAM_DEFAULT_CHAT_ID = "-1002738416282" // NEW DEFAULT CHAT ID

// === HARDCODED TWITTER CONFIG ===
const TWITTER_ACCOUNTS = [
  {
    id: 1,
    name: "Account 1",
    apiKey: "o7MteZPWiqK2bnlNdJQj47mX4",
    apiSecret: "ivC4WoIg34AnW4jB57gUSka9GcRt8DiazRvJWEYje9RmyYL6rm",
    accessToken: "873912682599956485-Rd4fb7EiZkN8XqrHafsIeKgxfmM4IZk",
    accessTokenSecret: "4m048JDKDAM6YG3FGlfgDwmyOQKV9tvf94ZitdSDA2L0N",
  },
  {
    id: 2,
    name: "Account 2",
    apiKey: "ubtsxen4ihWhwyTJH3PNvpDrd",
    apiSecret: "4LIdu9kZbcewfXUGSUSEFAP6sw4ZDDchIzieDQ4Q5ayenZvFOZ",
    accessToken: "891270264587202561-RYy79Dd8vEYBXb1fRurlOFj9f9dVkM3",
    accessTokenSecret: "4m048JDKDAM6YG3FGlfgDwmyOQKV9tvf94ZitdSDA2L0N",
  },
]

// Track current active Twitter account
let currentTwitterAccount = 0

// Escape MarkdownV2 untuk Telegram
function escapeMarkdown(text: string): string {
  return text
    .replace(/_/g, "\\_")
    .replace(/\*/g, "\\*")
    .replace(/\[/g, "\\[")
    .replace(/\]/g, "\\]")
    .replace(/\(/g, "\\(")
    .replace(/\)/g, "\\)")
    .replace(/~/g, "\\~")
    .replace(/`/g, "\\`")
    .replace(/>/g, "\\>")
    .replace(/#/g, "\\#")
    .replace(/\+/g, "\\+")
    .replace(/-/g, "\\-")
    .replace(/=/g, "\\=")
    .replace(/\|/g, "\\|")
    .replace(/\{/g, "\\{")
    .replace(/\}/g, "\\}")
    .replace(/\./g, "\\.")
    .replace(/!/g, "\\!")
}

// Generate OAuth 1.0a signature for Twitter API
function generateOAuthSignature(
  method: string,
  url: string,
  params: Record<string, string>,
  consumerSecret: string,
  tokenSecret: string,
): string {
  // Sort parameters alphabetically
  const sortedParams = Object.keys(params)
    .sort()
    .map((key) => `${encodeURIComponent(key)}=${encodeURIComponent(params[key])}`)
    .join("&")

  // Create signature base string
  const signatureBaseString = `${method.toUpperCase()}&${encodeURIComponent(url)}&${encodeURIComponent(sortedParams)}`

  // Create signing key
  const signingKey = `${encodeURIComponent(consumerSecret)}&${encodeURIComponent(tokenSecret)}`

  // Generate signature using HMAC-SHA1
  const signature = createHmac("sha1", signingKey).update(signatureBaseString).digest("base64")

  return signature
}

// Generate OAuth authorization header
function generateOAuthHeader(
  method: string,
  url: string,
  consumerKey: string,
  consumerSecret: string,
  accessToken: string,
  accessTokenSecret: string,
): string {
  // Generate OAuth parameters
  const oauthParams = {
    oauth_consumer_key: consumerKey,
    oauth_token: accessToken,
    oauth_signature_method: "HMAC-SHA1",
    oauth_timestamp: Math.floor(Date.now() / 1000).toString(),
    oauth_nonce: randomBytes(16).toString("hex"),
    oauth_version: "1.0",
  }

  // Generate signature
  const signature = generateOAuthSignature(method, url, oauthParams, consumerSecret, accessTokenSecret)
  oauthParams.oauth_signature = signature

  // Create authorization header
  const authHeader =
    "OAuth " +
    Object.keys(oauthParams)
      .map((key) => `${key}="${encodeURIComponent(oauthParams[key])}"`)
      .join(", ")

  return authHeader
}

// Post to Twitter using OAuth 1.0a
async function postToTwitter(message: string, accountIndex: number): Promise<{ success: boolean; error?: string }> {
  try {
    const account = TWITTER_ACCOUNTS[accountIndex]
    const url = "https://api.twitter.com/2/tweets"

    // Limit message to Twitter's character limit
    const tweetText = message.length > 280 ? message.substring(0, 277) + "..." : message

    // Generate OAuth authorization header
    const authHeader = generateOAuthHeader(
      "POST",
      url,
      account.apiKey,
      account.apiSecret,
      account.accessToken,
      account.accessTokenSecret,
    )

    console.log(`🐦 Posting to Twitter using ${account.name}...`)

    const response = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: authHeader,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        text: tweetText,
      }),
    })

    if (!response.ok) {
      const errorData = await response.json()
      console.error(`❌ Twitter API Error (${account.name}):`, errorData)

      // Check for rate limit errors
      if (
        response.status === 429 ||
        errorData.title?.includes("rate limit") ||
        errorData.title?.includes("Rate limit")
      ) {
        return { success: false, error: "rate limit exceeded" }
      }

      return { success: false, error: errorData.detail || errorData.title || `HTTP ${response.status}` }
    }

    const data = await response.json()
    console.log(`✅ Tweet posted successfully using ${account.name}:`, data.data?.id)
    return { success: true }
  } catch (error) {
    console.error(`❌ Network error with ${TWITTER_ACCOUNTS[accountIndex].name}:`, error)
    return { success: false, error: `Network error: ${error.message}` }
  }
}

// Post to Twitter with automatic account switching
async function postToTwitterWithFailover(
  message: string,
): Promise<{ success: boolean; accountUsed?: number; error?: string }> {
  // Try current account first
  console.log(`🔄 Attempting Twitter post with Account ${currentTwitterAccount + 1}...`)
  let result = await postToTwitter(message, currentTwitterAccount)

  if (result.success) {
    return { success: true, accountUsed: currentTwitterAccount + 1 }
  }

  // If failed due to rate limit, try the other account
  if (result.error?.includes("rate limit")) {
    const nextAccount = currentTwitterAccount === 0 ? 1 : 0
    console.log(`⚠️ Account ${currentTwitterAccount + 1} hit rate limit, switching to Account ${nextAccount + 1}...`)

    // Switch to other account
    currentTwitterAccount = nextAccount
    result = await postToTwitter(message, currentTwitterAccount)

    if (result.success) {
      return { success: true, accountUsed: currentTwitterAccount + 1 }
    }
  }

  return { success: false, error: result.error }
}

const HISTORY_REDIS_KEY = "webhook_history_v2" // Kunci riwayat yang baru

export async function POST(request: NextRequest) {
  let alertText = ""

  try {
    const contentType = request.headers.get("content-type") || ""

    // 1. JSON alert dari TradingView (format: { message: "..." })
    if (contentType.includes("application/json")) {
      const body = await request.json()
      if (body.message) {
        alertText = body.message
      } else {
        return NextResponse.json({ error: "Invalid JSON: missing `message` key" }, { status: 400 })
      }
    }
    // 2. Plaintext alert langsung
    else {
      const body = await request.text()
      if (typeof body === "string" && body.trim()) {
        // Replace literal '\n' with real line breaks
        alertText = body.replace(/\\n/g, "\n")
      } else {
        return NextResponse.json({ error: "Unsupported content type or empty body" }, { status: 400 })
      }
    }

    console.log(`📨 Processing webhook message: "${alertText.substring(0, 100)}${alertText.length > 100 ? "..." : ""}"`)

    const results = {
      telegram: { success: false, error: null, chatId: null }, // Add chatId to results
      twitter: { success: false, error: null, accountUsed: null },
    }

    // Determine Telegram Chat ID based on message content
    let targetChatId: string | null = null
    for (const mapping of TELEGRAM_CHAT_MAP) {
      if (mapping.keywords.some((keyword) => alertText.includes(keyword))) {
        targetChatId = mapping.chatId
        break // Use the first matching group
      }
    }

    // If no specific keyword is found, use the default chat ID
    if (!targetChatId) {
      targetChatId = TELEGRAM_DEFAULT_CHAT_ID
      console.log(`ℹ️ No specific Telegram group keyword found. Sending to default group: ${targetChatId}`)
    }

    // Send to both platforms simultaneously
    const [telegramPromise, twitterPromise] = await Promise.allSettled([
      // Send to Telegram
      (async () => {
        const escapedMessage = escapeMarkdown(alertText)
        const response = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            chat_id: targetChatId,
            text: escapedMessage,
            parse_mode: "MarkdownV2",
          }),
        })

        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.description || "Telegram API error")
        }

        return response.json()
      })(),

      // Send to Twitter
      postToTwitterWithFailover(alertText),
    ])

    // Process Telegram result
    if (telegramPromise.status === "fulfilled") {
      results.telegram.success = true
      results.telegram.chatId = targetChatId
      console.log(`✅ Alert sent to Telegram group: ${targetChatId}.`)
    } else {
      results.telegram.success = false
      results.telegram.error = telegramPromise.reason.message
      results.telegram.chatId = targetChatId // Still record the intended chat ID
      console.error("❌ Failed to send to Telegram:", telegramPromise.reason.message)
    }

    // Process Twitter result
    if (twitterPromise.status === "fulfilled") {
      const twitterResult = twitterPromise.value
      results.twitter.success = twitterResult.success
      results.twitter.accountUsed = twitterResult.accountUsed
      results.twitter.error = twitterResult.error

      if (twitterResult.success) {
        console.log(`✅ Alert posted to Twitter (Account ${twitterResult.accountUsed}).`)
      } else {
        console.error("❌ Failed to post to Twitter:", twitterResult.error)
      }
    } else {
      results.twitter.error = twitterPromise.reason.message
      console.error("❌ Twitter promise rejected:", twitterPromise.reason.message)
    }

    // Determine response based on results
    const telegramSuccess = results.telegram.success
    const twitterSuccess = results.twitter.success

    // --- START: Penambahan untuk menyimpan riwayat ke Upstash Redis ---
    const historyEntry = {
      timestamp: new Date().toISOString(),
      message: alertText,
      telegram: {
        success: results.telegram.success,
        chatId: results.telegram.chatId,
        error: results.telegram.error,
      },
      twitter: {
        success: results.twitter.success,
        accountUsed: results.twitter.accountUsed,
        error: results.twitter.error,
      },
    }

    let currentHistory: any[] = []
    try {
      const redisHistory = await redis.get<any[]>(HISTORY_REDIS_KEY)
      if (redisHistory) {
        currentHistory = redisHistory
        console.log(`ℹ️ Retrieved existing history from Upstash Redis.`)
      } else {
        console.log(`ℹ️ ${HISTORY_REDIS_KEY} does not exist yet in Upstash Redis. Starting new history.`)
      }
    } catch (error) {
      console.warn(
        `⚠️ Error retrieving existing history from Upstash Redis (${HISTORY_REDIS_KEY}). Starting new history.`,
        error,
      )
    }

    currentHistory.unshift(historyEntry) // Add to the beginning
    if (currentHistory.length > 100) {
      // Keep only the last 100 entries
      currentHistory = currentHistory.slice(0, 100)
    }

    try {
      await redis.set(HISTORY_REDIS_KEY, currentHistory)
      console.log(`✅ History updated in Upstash Redis: ${HISTORY_REDIS_KEY}`)
    } catch (redisSetError) {
      console.error(`❌ Failed to save history to Upstash Redis:`, redisSetError)
      // Decide if this should cause a 500 for the webhook itself.
      // For now, let's let the webhook continue if other operations were successful.
    }
    // --- END: Penambahan untuk menyimpan riwayat ke Upstash Redis ---

    if (telegramSuccess && twitterSuccess) {
      return NextResponse.json(
        {
          message: `✅ Alert forwarded to Telegram (Group ${results.telegram.chatId}) and Twitter (Account ${results.twitter.accountUsed}).`,
          results,
        },
        { status: 200 },
      )
    } else if (telegramSuccess) {
      return NextResponse.json(
        {
          message: `✅ Alert forwarded to Telegram (Group ${results.telegram.chatId}). ⚠️ Twitter posting failed.`,
          results,
        },
        { status: 200 },
      )
    } else if (twitterSuccess) {
      return NextResponse.json(
        {
          message: `✅ Alert posted to Twitter (Account ${results.twitter.accountUsed}). ⚠️ Telegram sending failed.`,
          results,
        },
        { status: 200 },
      )
    } else {
      return NextResponse.json(
        {
          message: "❌ Failed to send to both Telegram and Twitter.",
          results,
        },
        { status: 500 },
      )
    }
  } catch (error) {
    console.error("❌ Webhook error:", error)
    return NextResponse.json({ error: "❌ Failed to process webhook request." }, { status: 500 })
  }
}

// Handle other HTTP methods
export async function GET() {
  return NextResponse.json(
    {
      message: "Webhook endpoint is active. Use POST method to send alerts.",
      endpoint: "/api/webhook",
      methods: ["POST"],
      formats: ["JSON with 'message' key", "Plain text"],
      integrations: {
        telegram: "Active (dynamic chat ID based on message content)",
        twitter: `Active (2 accounts with auto-failover, currently using Account ${currentTwitterAccount + 1})`,
      },
    },
    { status: 200 },
  )
}
